<?php
session_start();
require 'config.php';

$insertResult = $searchResult = $deleteResult = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['insert'])) {
        $id = intval($_POST['insertId']);
        $title = $_POST['insertTitle'];
        $author = $_POST['insertAuthor'];
        $sql = "INSERT INTO libros (id, titulo, autor) VALUES ('$id', '$title', '$author')";
        if ($conn->query($sql) === TRUE) {
            $insertResult = 'Libro insertado';
        } else {
            $insertResult = "Error: " . $conn->error;
        }
    } elseif (isset($_POST['search'])) {
        $id = intval($_POST['searchId']);
        $sql = "SELECT * FROM libros WHERE id = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $book = $result->fetch_assoc();
            $searchResult = "ID: {$book['id']}, Título: {$book['titulo']}, Autor: {$book['autor']}";
        } else {
            $searchResult = 'Libro no encontrado';
        }
    } elseif (isset($_POST['delete'])) {
        $id = intval($_POST['deleteId']);
        $sql = "DELETE FROM libros WHERE id = '$id'";
        if ($conn->query($sql) === TRUE) {
            $deleteResult = 'Libro eliminado';
        } else {
            $deleteResult = "Error: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca con BST</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 600px; margin: auto; padding: 20px; }
        form { margin-bottom: 20px; }
        input[type="text"], input[type="number"] { width: 100%; padding: 8px; margin-bottom: 10px; }
        button { padding: 10px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .result { margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Biblioteca con BST</h1>
        
        <h2>Insertar Libro</h2>
        <form method="post">
            <input type="number" name="insertId" placeholder="ID del Libro" required>
            <input type="text" name="insertTitle" placeholder="Título del Libro" required>
            <input type="text" name="insertAuthor" placeholder="Autor del Libro" required>
            <button type="submit" name="insert">Insertar Libro</button>
        </form>
        <div class="result"><?php echo $insertResult; ?></div>
        
        <h2>Buscar Libro</h2>
        <form method="post">
            <input type="number" name="searchId" placeholder="ID del Libro" required>
            <button type="submit" name="search">Buscar Libro</button>
        </form>
        <div class="result"><?php echo $searchResult; ?></div>
        
        <h2>Eliminar Libro</h2>
        <form method="post">
            <input type="number" name="deleteId" placeholder="ID del Libro" required>
            <button type="submit" name="delete">Eliminar Libro</button>
        </form>
        <div class="result"><?php echo $deleteResult; ?></div>

        <h2>Imprimir Árbol BST</h2>
        <form method="post" action="impresion.php">
            <button type="submit" name="print">Imprimir Árbol</button>
        </form>
    </div>
</body>
</html>
