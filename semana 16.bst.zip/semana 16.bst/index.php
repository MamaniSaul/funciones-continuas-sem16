<?php
header("Location: biblioteca.php");
exit();
?>
