<?php
require 'config.php';

class Book {
    public $id;
    public $title;
    public $author;

    function __construct($id, $title, $author) {
        $this->id = $id;
        $this->title = $title;
        $this->author = $author;
    }
}

class BSTNode {
    public $book;
    public $left;
    public $right;

    function __construct($book) {
        $this->book = $book;
        $this->left = null;
        $this->right = null;
    }
}

class BST {
    public $root;

    function __construct() {
        $this->root = null;
    }

    function insert($book) {
        $newNode = new BSTNode($book);
        if ($this->root === null) {
            $this->root = $newNode;
        } else {
            $this->insertNode($this->root, $newNode);
            $this->balanceTree();
        }
    }

    function insertNode($node, $newNode) {
        if ($newNode->book->id < $node->book->id) {
            if ($node->left === null) {
                $node->left = $newNode;
            } else {
                $this->insertNode($node->left, $newNode);
            }
        } else {
            if ($node->right === null) {
                $node->right = $newNode;
            } else {
                $this->insertNode($node->right, $newNode);
            }
        }
    }

    function inOrder($node) {
        $result = [];
        if ($node !== null) {
            $result = array_merge($result, $this->inOrder($node->left));
            $result[] = $node->book;
            $result = array_merge($result, $this->inOrder($node->right));
        }
        return $result;
    }

    function printTree() {
        $books = $this->inOrder($this->root);
        return $books;
    }

    private function balanceTree() {
        $nodes = $this->inOrder($this->root);
        $this->root = $this->buildBalancedTree($nodes, 0, count($nodes) - 1);
    }

    private function buildBalancedTree($nodes, $start, $end) {
        if ($start > $end) {
            return null;
        }

        $mid = (int) (($start + $end) / 2);
        $node = new BSTNode($nodes[$mid]);

        $node->left = $this->buildBalancedTree($nodes, $start, $mid - 1);
        $node->right = $this->buildBalancedTree($nodes, $mid + 1, $end);

        return $node;
    }
}

$bst = new BST();
$sql = "SELECT * FROM libros";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $book = new Book($row['id'], $row['titulo'], $row['autor']);
    $bst->insert($book);
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Impresión del Árbol BST</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 800px; margin: auto; padding: 20px; position: relative; }
        .tree { display: flex; flex-direction: column; align-items: center; position: relative; }
        .node { padding: 10px; border: 2px solid #4CAF50; border-radius: 50%; margin: 10px; background-color: #e8f5e9; position: absolute; }
        .children { display: flex; justify-content: center; }
        .line { stroke: #4CAF50; stroke-width: 2; }
        #backButton {
            position: absolute; 
            top: 20px; 
            right: 20px; 
            padding: 10px; 
            background-color: #4CAF50; 
            color: white; 
            border: none; 
            cursor: pointer; 
        }
        #backButton:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <button id="backButton" onclick="location.href='biblioteca.php'">Regresar a Biblioteca</button>
    <div class="container">
        <h1>Árbol BST Balanceado</h1>
        <div class="tree" id="tree">
            <?php
            function displayNode($node, $level = 0, $x = 0, $y = 0) {
                if ($node !== null) {
                    $id = $node->book->id;
                    $title = $node->book->title;
                    $author = $node->book->author;
                    echo '<div class="node" data-id="' . $id . '" style="left: ' . $x . 'px; top: ' . $y . 'px;">ID: ' . $id . '<br>Título: ' . $title . '<br>Autor: ' . $author . '</div>';
                    
                    $childXOffset = 120 / pow(2, $level + 1);
                    $childYOffset = 100;

                    if ($node->left !== null) {
                        displayNode($node->left, $level + 1, $x - $childXOffset, $y + $childYOffset);
                    }
                    if ($node->right !== null) {
                        displayNode($node->right, $level + 1, $x + $childXOffset, $y + $childYOffset);
                    }
                }
            }

            displayNode($bst->root);
            ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const nodes = document.querySelectorAll('.node');
            const svgNS = "http://www.w3.org/2000/svg"; 
            const tree = document.getElementById('tree');

            nodes.forEach(node => {
                const id = node.getAttribute('data-id');
                const nodeRect = node.getBoundingClientRect();

                const childNodes = Array.from(nodes).filter(n => {
                    const childRect = n.getBoundingClientRect();
                    return childRect.top > nodeRect.top && Math.abs(childRect.left - nodeRect.left) < 150;
                });

                childNodes.forEach(childNode => {
                    const childRect = childNode.getBoundingClientRect();
                    
                    const line = document.createElementNS(svgNS, 'line');
                    line.setAttribute('x1', nodeRect.left + nodeRect.width / 2);
                    line.setAttribute('y1', nodeRect.top + nodeRect.height);
                    line.setAttribute('x2', childRect.left + childRect.width / 2);
                    line.setAttribute('y2', childRect.top);
                    line.setAttribute('class', 'line');

                    const arrowhead = document.createElementNS(svgNS, 'polygon');
                    arrowhead.setAttribute('points', '0,0 5,10 10,0');
                    arrowhead.setAttribute('fill', '#4CAF50');

                    const arrowTransform = `translate(${childRect.left + childRect.width / 2 - 5}, ${childRect.top - 5})`;
                    arrowhead.setAttribute('transform', arrowTransform);

                    tree.appendChild(line);
                    tree.appendChild(arrowhead);
                });
            });
        });
    </script>
</body>
</html>
